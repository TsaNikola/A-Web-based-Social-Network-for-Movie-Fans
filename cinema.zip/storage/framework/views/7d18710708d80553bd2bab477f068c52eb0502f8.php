<script>
    $(document).ready(function(){
        $('.home-box').hover(function(){
            var ribbonheight=$(this).find('.hb-ribbon').height();
            var boxheight=$(this).height();
            var midheight=(boxheight/2)-(ribbonheight/2);
            $(this).find('.hb-ribbon').css('bottom',midheight);
            $(this).find('.hb-ribbon').css('visibility','visible');
            $(this).find('.hb-ribbon').css('opacity','1');
        },function () {
            $(this).find('.hb-ribbon').css('bottom','0');
            $(this).find('.hb-ribbon').css('visibility','hidden');
            $(this).find('.hb-ribbon').css('opacity','0');
        });
    });
</script>
<span class="search-close">X</span>
<div class="container-fluid search-results-container ">

    <ul class="search-tabs nav navbar-nav">
        <?php if(isset($movies[0])): ?>
            <li class="search-tab active">
                <span>Movies Found</span>
            </li>
        <?php endif; ?>
        <?php if(isset($credits[0])): ?>
                <li class="search-tab <?php if(!isset($movies[0])): ?> active <?php endif; ?>">
                    <span>Credits Found</span>
                </li>
        <?php endif; ?>
            <?php if(isset($users[0])): ?>
                <li class="search-tab <?php if(!isset($movies[0]) && !isset($credits[0])): ?> active <?php endif; ?>">
                    <span>Users Found</span>
                </li>
            <?php endif; ?>
    </ul>

<?php if(isset($movies[0])): ?>
    <div class="movies-search-results row">
        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="hgrid">
                    <a class="hb-link" href="<?php echo e(route('movie',array('id'=>$movie->idMovie))); ?>">
                        <div class="home-box <?php if($movie->releaseDate>=date("YYYY-mm-dd")): ?> home <?php elseif($movie->popularity>=4): ?> popular <?php endif; ?>">

                            <?php if($movie['poster']!=''): ?>
                                <div class="hb-image"><img src="https://image.tmdb.org/t/p/w130<?php echo e($movie['poster']); ?>">
                                    <div class="hb-ribbon"><?php echo e($movie->title); ?>   <?php if($movie->releaseDate!=0): ?> (<?php echo e(substr($movie->releaseDate,0,4)); ?>)   <?php endif; ?></div>
                                </div>
                            <?php else: ?>
                                <div  class="hb-image" style="background-image: url('/cinema/public/img/default_poster.jpg')"></div>
                            <?php endif; ?>


                        </div>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

    <?php if(isset($credits[0])): ?>
        <div class="credits-search-results row display-none">
            <?php $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2 movie-credit">
                    <a href="<?php echo e(route('credit',array('id'=>$credit->idPerson))); ?>" class="credit-found-link" target="_blank">
                        <div class="credit-grid-item row">
                            <div class="credit-found-info-cont-outer col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <div class="credit-found-img-cont  col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                    <?php if($credit->picture!=''): ?>
                                        <img class="credit-found-img" alt="<?php echo e($credit->name); ?>" src="https://image.tmdb.org/t/p/w130<?php echo e($credit->picture); ?>">
                                    <?php else: ?>
                                        <img class="credit-found-img" alt="<?php echo e($credit->name); ?>" src="/cinema/public/img/no_avatar.jpg">
                                    <?php endif; ?>
                                </div>
                                <div class="user-found-info-cont"><span></span><span class="mov-cast-name"><?php echo e($credit->name); ?></span></div>
                                <?php if($credit->birthday!=''): ?>

                                <?php else: ?>
                                 
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if(isset($users[0])): ?>
        <div class="users-search-results row display-none">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="user-found col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <a href="<?php echo e(route('user',array('id'=>$user->idUser))); ?>" class="user-found-link">
                        <div class="user-found-poster">
                            <?php if($user->image!=''): ?>
                            <img alt="<?php echo e($user->username); ?>" src="/img/users/<?php echo e($user->image); ?>">
                            <?php else: ?>
                                <img alt="<?php echo e($user->username); ?>" src="/cinema/public/img/no_avatar.jpg">
                            <?php endif; ?>
                            <span class="user-found-title"><?php echo e($user->username); ?></span>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

</div>
<?php if(!isset($movies[0]) && !isset($credits[0]) && !isset($users[0])): ?>
    <div class="search-no-results"><span>No Results Found</span></div>
<?php endif; ?>

<script>
    $(document).ready(function(){
        if($('.search-tabs .active').find('span').text()=='Movies Found'){
            if($('.movies-search-results').hasClass('display-none')) {
                $('.movies-search-results').removeClass('display-none');
                $('.movies-search-results').addClass('display-block');
                $('.credits-search-results').addClass('display-none');
                $('.users-search-results').addClass('display-none');
            }
        }else if($('.search-tabs .active').find('span').text()=='Credits Found'){
            if($('.credits-search-results').hasClass('display-none')){
                $('.credits-search-results').removeClass('display-none');
                $('.credits-search-results').addClass('display-block');
                $('.users-search-results').addClass('display-none');
                $('.movies-search-results').addClass('display-none');
            }
        }else if($('.search-tabs .active').find('span').text()=='Users Found'){
            if( $('.users-search-results').hasClass('display-none')) {
                $('.users-search-results').removeClass('display-none');
                $('.users-search-results').addClass('display-block');
                $('.credits-search-results').addClass('display-none');
                $('.movies-search-results').addClass('display-none');
            }
        }

$('.search-tab').click(function(){
    if($(this).find('span').text()=='Movies Found'){
        if($('.movies-search-results').hasClass('display-none')) {
            $('.movies-search-results').removeClass('display-none');
            $('.movies-search-results').addClass('display-block');
            $('.credits-search-results').addClass('display-none');
            $('.users-search-results').addClass('display-none');
        }
    }else if($(this).find('span').text()=='Credits Found'){
        if($('.credits-search-results').hasClass('display-none')){
            $('.credits-search-results').removeClass('display-none');
            $('.credits-search-results').addClass('display-block');
            $('.users-search-results').addClass('display-none');
            $('.movies-search-results').addClass('display-none');
        }
    }else if($(this).find('span').text()=='Users Found'){
        if( $('.users-search-results').hasClass('display-none')) {
            $('.users-search-results').removeClass('display-none');
            $('.users-search-results').addClass('display-block');
            $('.credits-search-results').addClass('display-none');
            $('.movies-search-results').addClass('display-none');
        }
    }
    $('.search-tab').removeClass('active');
    $(this).addClass('active');
});
    });
</script>