<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        $(document).ready(function(){
        $('.home-box').hover(function(){
            var ribbonheight=$(this).find('.hb-ribbon').height();
                        var boxheight=$(this).height();
            var midheight=(boxheight/2)-(ribbonheight/2);
//                        var midheight=((boxheight-ribbonheight)/2)+(ribbonheight/2);
//            alert(midheight);
            $(this).find('.hb-ribbon').css('bottom',midheight);
            $(this).find('.hb-ribbon').css('visibility','visible');
            $(this).find('.hb-ribbon').css('opacity','1');
        },function () {
            $(this).find('.hb-ribbon').css('bottom','0');
            $(this).find('.hb-ribbon').css('visibility','hidden');
            $(this).find('.hb-ribbon').css('opacity','0');
        });
        });
    </script>


    <div class="container">

        <div class="row">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">



                <div class="home-boxes" id="main-box">
                    <div class="container-fluid">


                            <div class="series-cont-h row">

                                <div id="load-0">




                                    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                                
                                                    
                                                    

                                                        
                                                            
                                                        
                                                            
                                                        
                                                            
                                                        
                                                        
                                                            

                                                        

                                                    
                                                    
                                                
                                        

                                        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2">
                                            <div class="hgrid">
                                                <a class="hb-link" href="<?php echo e(route('movie',array('id'=>$movie->idMovie))); ?>">
                                                    <div class="home-box <?php if($movie->releaseDate>=date("YYYY-mm-dd")): ?> home <?php elseif($movie->popularity>=4): ?> popular <?php endif; ?>">

                                                        <?php if($movie['poster']!=''): ?>
                                                            <div  class="hb-image"><img src="https://image.tmdb.org/t/p/w130<?php echo e($movie['poster']); ?>">
                                                                <div class="hb-ribbon"><?php echo e($movie->title); ?>   <?php if($movie->releaseDate!=0): ?> (<?php echo e(substr($movie->releaseDate,0,4)); ?>)   <?php endif; ?></div>
                                                            </div>
                                                       <?php else: ?>
                                                            <div class="hb-image" style="background-image: url('/img/default_poster.jpg')"></div>
                                                        <?php endif; ?>


                                                    </div>
                                                </a>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div id="load-0-end"></div>

                                </div>


                            </div>


                    </div>
                </div>
            </div>
        </div>
    </div>





    </div>
    </div>


    <div class="pegination">
        <?php echo e($movies->links()); ?>

    </div>
    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>