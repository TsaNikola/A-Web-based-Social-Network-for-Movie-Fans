<?php $__env->startSection('content'); ?>
<?php echo $__env->make('menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php
header('X-Frame-Options:Allow-From https://www.youtube.com');
?>


    <div class="movie-page-bg" style="background-image: url('https://image.tmdb.org/t/p/original<?php echo e($backgrounds[array_rand($backgrounds)]); ?>');">
<div class="movie-page-bg-cover" >


    <div id="wallp-close" class="wallp-close display-none">
        <i class="fa fa-window-close" aria-hidden="true"></i>
    </div>

    <div id="left-arrow" class="wallp-arrow display-none">
        <i class="fa fa-chevron-circle-left" aria-hidden="true"></i>
    </div>

    <div id="right-arrow" class="wallp-arrow display-none">
        <i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
    </div>

    <div class="container">

        <div class="row">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="movie-info">
                    <div class="main-info">
                        <div class="title">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="movie-title"><?php echo e($movie['title']); ?></div>
                                </div>
                                
                                    
                                        
                                
                            </div>
                        </div>
                    </div>
                    
                        
                            
                            
                            
                            
                                
                            
                        
                        
                            
                            
                        
                    
                </div>
        </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3 col-xl-3">
                <div class="movie-info poster-cont">
                    <img src="https://image.tmdb.org/t/p/w780<?php echo e($movie['poster']); ?>" class="poster-image">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-9 col-xl-9 movie-details">
                <div class="movie-info">
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    <div class="secondary-info">
                        <div class="info-left col-xs-12 col-sm-7 col-md-8 col-lg-8">
                            <div class="secondary-info-yrg">
                            <span class="quality-label">Year:</span>
                            <span class="quality"><?php echo e(substr($movie['releaseDate'],0,4)); ?></span>
                            <span class="quality-label genr">Rating:</span>
                            <span class="quality"><?php echo e($movie['rating']); ?></span>
                            <span class="quality-label genr">Genres:</span>
                            </div>
                            <ul class="genre">
                                <?php $__currentLoopData = $movie['genres']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($genre); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-xs-12 col-sm-5 col-md-4 col-lg-4">
                            <button class=" movie-title-right" type=""><span class="quality-label">Followers:</span>
                                <span class="quality"><?php echo e(count($movie['followers'])); ?></span></button>
                            <button class=" movie-title-right follow" type=""><span class="quality-label">Follow</span>
                                </button>
                        </div>
                    </div>
                </div>
                <div class="movie-info">

                    <div class="secondary-info">
                        <div><span>Description</span></div>
                        <div><span><?php echo e($movie['description']); ?></span></div>

                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="movie-menu">
                    <div class="collapse navbar-collapse  movie-menu inner-movie-menu" >
                        <ul class="nav navbar-nav movie-menu-list">
                            <li class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                <a href="#movie-comments" class="active">Comments</a>
                            </li>
                            <li class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 dropdown dropdown-hover">
                                <a href="#movie-trailers" > Trailers</a>
                            </li>
                            <li class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                <a href="#movie-wallpapers">Wallpapers</a>
                            </li>
                            <li  class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 dropdown dropdown-hover">
                                <a  href="#movie-cast">Cast</a>
                            </li>
                            <li  class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 dropdown dropdown-hover">
                                <a  href="#movie-crew">Crew</a>
                            </li>
                            <li  class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 dropdown dropdown-hover">
                                <a  href="#movie-followers">Followers</a>
                            </li>
                        </ul>

                    </div>
                </div>
                <div id="movie-comments" class="movie-data-cont col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="comment-cont">
                        <?php $__currentLoopData = $movie['comments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="movie-comment col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                <a href="<?php echo e(route("user",array("id"=>$comment['userCommentId']))); ?>">
                                <div class="comment-user-image-outter col-xs-4 col-sm-3 col-md-2 col-lg-1 col-xl-1">

                                    <?php if($comment['image']!=''): ?>
                                        <img alt="<?php echo e($comment['username']); ?>-<?php echo e($comment['idComment']); ?>" src="/img/users/<?php echo e($comment['image']); ?>" class="comment-image">
                                    <?php else: ?>
                                        <img alt="<?php echo e($comment['username']); ?>-<?php echo e($comment['idComment']); ?>" src="/cinema/public/img/no_avatar.jpg" class="comment-image">
                                    <?php endif; ?>
                                        <div class="comment-user-name">
                                            <span><?php echo e($comment['username']); ?></span>
                                        </div>
                                </div>
                                </a>
                                <div class="comment-user col-xs-8 col-sm-9 col-md-12 col-lg-11 col-xl-11">

                                <div class="comment-user-date">
                                    <span><i><?php echo e(date("M jS, Y - H:i",strtotime($comment['publishDate']))); ?></i></span>
                                </div>
                                </div>
                                <div class="comment-user col-xs-8 col-sm-9 col-md-12 col-lg-11 col-xl-11">
                                    <span><?php echo e($comment['content']); ?></span>
                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

                <div id="movie-trailers" style="display: none;" class="movie-data-cont col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="trailer-widget">
                        <h2>Trailers</h2>
                        <div class=" row trailer-list">
                            <?php $__currentLoopData = $movie['trailers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$trailer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <iframe width="0" height="0" src="https://www.youtube.com/embed/<?php echo e($trailer['filename']); ?>" frameborder="0" allowfullscreen></iframe>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $movie['trailers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$trailer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="trailer-<?php echo e($key); ?> trailer-cont col-xs-12 col-sm-6 col-md-12 col-lg-12">
                                <div class="trailer-box">
                                    <div class="tb-details">
                                        <strong><?php echo e($trailer['tag']); ?></strong>
                                    </div>

                                    <div class="tb-video">
                                          <iframe width="100%" height="auto" src="https://www.youtube.com/embed/<?php echo e($trailer['filename']); ?>" frameborder="0" allowfullscreen></iframe>
                                      </div>
                            </div>
                        </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>

                </div>

                <div id="movie-wallpapers" style="display: none;" class="movie-data-cont col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <?php $__currentLoopData = $movie['wallpapers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$wallpaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="wallpaper-<?php echo e($key+1); ?>-<?php echo e(count($movie['wallpapers'])); ?>" class="wallpaper-cont col-xs-12 col-sm-6 col-md-4 col-lg-3">
                        <img alt="<?php echo e($movie['title']); ?>} | Wallpaper-<?php echo e($key); ?>" src="https://image.tmdb.org/t/p/original<?php echo e($wallpaper); ?>" class="wallpaper" style="width:100%;height:100%;">
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div id="movie-cast" style="display: none;" class="movie-data-cont col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

                    <div class="credits-search-results row" style="margin-left: 15px;">
                        <?php $__currentLoopData = $movie['cast']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 movie-credit">
                                <a href="<?php echo e(route('credit',array('id'=>$credit['idPerson']))); ?>" class="credit-found-link" target="_blank">
                                    <div class="credit-grid-item row">
                                        <div class="movie-credit-info-cont-outer col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            <div class="movie-credit-img-cont  col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                                <?php if($credit['picture']!=''): ?>
                                                    <img class="credit-found-img" alt="<?php echo e($credit['name']); ?>" src="https://image.tmdb.org/t/p/w130<?php echo e($credit['picture']); ?>">
                                                <?php else: ?>
                                                    <img class="credit-found-img" alt="<?php echo e($credit['name']); ?>" src="/cinema/public/img/no_avatar.jpg">
                                                <?php endif; ?>
                                            </div>
                                            <div class="movie-credit-info col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            <div class="movie-credit-info-cont"><span class="movie-cast-name"><?php echo e($credit['name']); ?></span></div>
                                            <div class="movie-credit-info-cont"><span class="movie-cast-name"><?php echo e($credit['character']); ?></span></div>
                                            </div>
                                            <?php if($credit['birthday']!=''): ?>
                                                
                                            <?php else: ?>
                                                
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div id="movie-crew" style="display: none;" class="movie-data-cont col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="credits-search-results row" style="margin-left: 15px;">
                        <?php $__currentLoopData = $movie['crew']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 movie-credit">
                                <a href="<?php echo e(route('credit',array('id'=>$credit['idPerson']))); ?>" class="credit-found-link" target="_blank">
                                    <div class="credit-grid-item row">
                                        <div class="movie-credit-info-cont-outer col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            <div class="movie-credit-img-cont  col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                                <?php if($credit['picture']!=''): ?>
                                                    <img class="credit-found-img" alt="<?php echo e($credit['name']); ?>" src="https://image.tmdb.org/t/p/w130<?php echo e($credit['picture']); ?>">
                                                <?php else: ?>
                                                    <img class="credit-found-img" alt="<?php echo e($credit['name']); ?>" src="/cinema/public/img/no_avatar.jpg">
                                                <?php endif; ?>
                                            </div>
                                            <div class="movie-credit-info col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                                <div class="movie-credit-info-cont"><span class="movie-cast-name"><?php echo e($credit['name']); ?></span></div>
                                                <div class="movie-credit-info-cont"><span class="movie-cast-name"><?php echo e($credit['character']); ?></span></div>
                                            </div>
                                            <?php if($credit['birthday']!=''): ?>
                                                
                                            <?php else: ?>
                                                
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div id="movie-followers" style="display: none;" class="movie-data-cont col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="users-search-results row">
                        <?php $__currentLoopData = $movie['followers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="user-found col-xs-12 col-sm-6 col-md-2 col-lg-2 col-xl-2">
                                <a href="<?php echo e(route('user',array('id'=>$user['idUser']))); ?>" class="user-found-link">
                                    <div class="user-found-poster">
                                        <?php if($user['image']!=''): ?>
                                            <img alt="<?php echo e($user['username']); ?>" src="/img/users/<?php echo e($user['image']); ?>">
                                        <?php else: ?>
                                            <img alt="<?php echo e($user['username']); ?>" src="/cinema/public/img/no_avatar.jpg">
                                        <?php endif; ?>
                                        <span class="user-found-title"><?php echo e($user['username']); ?></span>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            </div>

    </div>





    </div>
</div>

</div>

<script>
    $(document).ready(function(){
$('.movie-menu-list').find('a').click(function(e){
    e.preventDefault();
    $('.movie-menu-list').find('a').each(function(){
        $(this).removeClass('active');
    });
    $(this).addClass('active');
    var tabid=$(this).attr('href');
    $('.movie-data-cont').each(function(){
        $(this).css('display','none');
    });
    $(tabid).css('display','block');
    if(tabid=='#movie-trailers'){
        var trailerwidth=$('.tb-video').find('iframe').width();
        var trailerheight=trailerwidth*62/100;
        $('.tb-video').find('iframe').each(function(){
            $(this).css('height',trailerheight);
        });
    }
});
    });
</script>

<script>
    $(document).ready(function(){
        var currw=null;
        var maxw =null;
        $(".wallpaper-cont").click(function() {
            var info=$(this).attr('id');
            var infotmp= info.split('-');
            currw =parseInt(infotmp[1]);
            maxw =parseInt(infotmp[2]);

            if($('.wallp-close').hasClass('display-none')){
                $('.wallp-close').removeClass('display-none');
                $('.wallp-arrow').removeClass('display-none');
                $(this).addClass('wallpaper-cont-act');
                $(this).find('img').addClass('wallpaper-active ');
            }
            else{
                $('.wallp-close').addClass('display-none');
                $('.wallp-arrow').addClass('display-none');
                $(this).removeClass('wallpaper-cont-act');
                $(this).find('img').removeClass('wallpaper-active');
            }
        });
        $(".wallp-close").click(function() {
            // alert('clicked');
            $('.wallp-close').addClass('display-none');
            $('.wallp-arrow').addClass('display-none');
            $(".wallpaper-cont").removeClass('wallpaper-cont-act');
            $(".wallpaper-cont").find('img').removeClass('wallpaper-active');
        });
        $("#left-arrow").click(function() {
            $(".wallpaper-cont").removeClass('wallpaper-cont-act');
            $(".wallpaper-cont").find('img').removeClass('wallpaper-active');

            if(currw==1){
                currw=10;
            }else{
                currw-=1;
            }
            // alert("#wallpaper-"+currw+"-"+maxw);
            $("#wallpaper-"+currw+"-"+maxw).addClass('wallpaper-cont-act');
            $("#wallpaper-"+currw+"-"+maxw).find('img').addClass('wallpaper-active');
        });
        $("#right-arrow").click(function() {
            $(".wallpaper-cont").removeClass('wallpaper-cont-act');
            $(".wallpaper-cont").find('img').removeClass('wallpaper-active');

            if(currw==maxw){
                currw=1;
            }else{
                currw+=1;
            }
            // alert("#wallpaper-"+currw+"-"+maxw);
            $("#wallpaper-"+currw+"-"+maxw).addClass('wallpaper-cont-act');
            $("#wallpaper-"+currw+"-"+maxw).find('img').addClass('wallpaper-active');
        });
    });
</script>
    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>