<?php $__env->startSection('content'); ?>
<?php echo $__env->make('menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <div class="movie-page-bg" >
<div class="movie-page-bg-cover" >



    <div class="container">

        <div class="row">
            <div class="pegination alpha-pagination">
                <ul class="pagination alphabet">
                    <?php $__currentLoopData = $alphabet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <?php if($firstChar==$ab): ?>
                    <li class="active"><a href="<?php echo e(route('all'.$creditype,array($ab))); ?>"><?php echo e(strtoupper($ab)); ?></a></li>
                     <?php else: ?>
                            <li><a href="<?php echo e(route('all'.$creditype,array($ab))); ?>"><?php echo e(strtoupper($ab)); ?></a></li>
                     <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>

                <div id="movie-cast" class="movie-data-cont col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

                    <div class="credits-search-results row" style="margin-left: 15px;">
                        <?php $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 movie-credit">
                                <a href="<?php echo e(route('credit',array('id'=>$credit['idPerson']))); ?>" class="credit-found-link" target="_blank">
                                    <div class="credit-grid-item row">
                                        <div class="movie-credit-info-cont-outer col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            <div class="movie-credit-img-cont  col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                                <?php if($credit['picture']!=''): ?>
                                                    <img class="credit-found-img" alt="<?php echo e($credit['name']); ?>" src="https://image.tmdb.org/t/p/w130<?php echo e($credit['picture']); ?>">
                                                <?php else: ?>
                                                    <img class="credit-found-img" alt="<?php echo e($credit['name']); ?>" src="/cinema/public/img/no_avatar.jpg">
                                                <?php endif; ?>
                                            </div>
                                            <div class="movie-credit-info col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            <div class="movie-credit-info-cont"><span class="movie-cast-name"><?php echo e($credit['name']); ?></span></div>
                                            </div>

                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
        </div>

        <div class="pegination credits-pagination">
            <?php echo e($credits->links()); ?>

        </div>

</div>


    </div>


    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>