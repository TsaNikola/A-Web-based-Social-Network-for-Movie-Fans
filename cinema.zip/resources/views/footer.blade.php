
<div class="container-fluid" id="footer">
    <div class="footer-outter">
    <a href="{{route("home")}}"><div id="copyright">Movies Community</div></a>
    <div id="copyright">© Copyright 2017</div>
    </div>
</div>